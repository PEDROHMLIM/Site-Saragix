import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Chess } from 'chess.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outFile = path.join(__dirname, 'openings-data', 'deep-mainlines.tsv');

export const DEEP_LINES = [
  // ==========================================
  // ECO A — FLANK OPENINGS, RETI, ENGLISH, DUTCH, LONDON, BENONI
  // ==========================================
  ["A04", "Reti Opening: Classical Line", "1. Nf3 d5 2. c4 e6 3. g3 Nf6 4. Bg2 Be7 5. O-O O-O 6. b3 c5 7. Bb2 Nc6 8. e3 b6 9. Nc3 Bb7 10. cxd5 Nxd5 11. Nxd5 Qxd5"],
  ["A09", "Reti Opening: Advance Variation", "1. Nf3 d5 2. c4 d4 3. b4 c5 4. Bb2 f6 5. e3 e5 6. exd4 cxd4 7. c5 a5 8. Bc4 axb4 9. Qb3 Nh6 10. O-O Bxc5"],
  ["A15", "English Opening: Anglo-Indian Defense, Four Knights", "1. c4 e5 2. Nc3 Nf6 3. Nf3 Nc6 4. g3 Bb4 5. Bg2 O-O 6. O-O e4 7. Ng5 Bxc3 8. bxc3 Re8 9. f3 exf3 10. Nxf3 d5"],
  ["A20", "English Opening: King's English, Keres Variation", "1. c4 e5 2. g3 c6 3. Nf3 e4 4. Nd4 d5 5. cxd5 Qxd5 6. Nc2 Nf6 7. Nc3 Qh5 8. Ne3 Bc5 9. Bg2 Bxe3 10. dxe3"],
  ["A29", "English Opening: Four Knights, Fianchetto Line", "1. c4 e5 2. Nc3 Nf6 3. Nf3 Nc6 4. g3 d5 5. cxd5 Nxd5 6. Bg2 Nb6 7. O-O Be7 8. a3 O-O 9. b4 Be6 10. Rb1 f6 11. d3 Nd4"],
  ["A30", "English Opening: Symmetrical Variation, Hedgehog", "1. c4 c5 2. Nf3 Nf6 3. Nc3 e6 4. g3 b6 5. Bg2 Bb7 6. O-O Be7 7. d4 cxd4 8. Qxd4 d6 9. Rd1 a6 10. b3 Nbd7 11. e4 O-O"],
  ["A33", "English Opening: Symmetrical Variation, Four Knights", "1. c4 c5 2. Nf3 Nf6 3. Nc3 Nc6 4. d4 cxd4 5. Nxd4 e6 6. g3 Qb6 7. Nb3 Ne5 8. e4 Bb4 9. Qe2 d6 10. f4"],
  ["A46", "London System: Classical Main Line", "1. d4 d5 2. Bf4 Nf6 3. e3 c5 4. c3 Nc6 5. Nd2 e6 6. Ngf3 Bd6 7. Bg3 O-O 8. Bd3 b6 9. Ne5 Bb7 10. f4 Ne7"],
  ["A46", "London System: vs King's Indian Defense", "1. d4 Nf6 2. Bf4 g6 3. e3 Bg7 4. Nf3 O-O 5. Be2 d6 6. h3 c5 7. c3 b6 8. O-O Bb7 9. a4 a6 10. Nbd2 Nbd7"],
  ["A45", "Trompowsky Attack: Main Line", "1. d4 Nf6 2. Bg5 Ne4 3. Bf4 c5 4. f3 Qa5+ 5. c3 Nf6 6. d5 Qb6 7. Bc1 e6 8. e4 exd5 9. exd5 Bd6 10. Qe2+ Kd8"],
  ["A48", "Torre Attack: Classical Line", "1. d4 Nf6 2. Nf3 e6 3. Bg5 c5 4. e3 Be7 5. Nbd2 b6 6. Bd3 Bb7 7. O-O O-O 8. c3 d6 9. Qe2 Nbd7"],
  ["A56", "Benoni Defense: Modern Benoni Classical Line", "1. d4 Nf6 2. c4 c5 3. d5 e6 4. Nc3 exd5 5. cxd5 d6 6. e4 g6 7. Nf3 Bg7 8. Be2 O-O 9. O-O Re8 10. Nd2 Nbd7 11. a4"],
  ["A57", "Benko Gambit: Accepted Main Line", "1. d4 Nf6 2. c4 c5 3. d5 b5 4. cxb5 a6 5. bxa6 g6 6. Nc3 Bxa6 7. g3 d6 8. Bg2 Bg7 9. Nf3 Nbd7 10. O-O O-O 11. Rb1"],
  ["A88", "Dutch Defense: Leningrad Variation, Main Line", "1. d4 f5 2. g3 Nf6 3. Bg2 g6 4. Nf3 Bg7 5. O-O O-O 6. c4 d6 7. Nc3 Qe8 8. d5 a5 9. Rb1 Na6"],
  ["A90", "Dutch Defense: Stonewall Classical", "1. d4 f5 2. g3 Nf6 3. Bg2 e6 4. Nf3 d5 5. O-O Bd6 6. c4 c6 7. b3 Qe7 8. Bb2 O-O 9. Qc2 Ne4 10. Nbd2 Nd7"],

  // ==========================================
  // ECO B — SICILIAN, CARO-KANN, SCANDINAVIAN, PIRC
  // ==========================================
  ["B18", "Caro-Kann Defense: Classical Variation, Capablanca Line", "1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. h4 h6 7. Nf3 Nd7 8. h5 Bh7 9. Bd3 Bxd3 10. Qxd3 e6 11. Bd2 Ngf6 12. O-O-O Be7 13. Kb1 O-O 14. Ne4 Nxe4 15. Qxe4 Nf6 16. Qe2 Qd5"],
  ["B12", "Caro-Kann Defense: Advance Variation, Short System", "1. e4 c6 2. d4 d5 3. e5 Bf5 4. Nf3 e6 5. Be2 c5 6. Be3 Qb6 7. Nc3 Nc6 8. O-O Qxb2 9. Qe1 cxd4 10. Bxd4 Nxd4 11. Nxd4 Bb4 12. Ndb5 Ba5"],
  ["B12", "Caro-Kann Defense: Advance Variation, Tal System", "1. e4 c6 2. d4 d5 3. e5 Bf5 4. h4 h5 5. c4 e6 6. Nc3 Ne7 7. Nge2 Nd7 8. Ng3 Bg6 9. Bg5 Qb6 10. Qd2 dxc4 11. Bxc4 O-O-O"],
  ["B14", "Caro-Kann Defense: Panov-Botvinnik Attack", "1. e4 c6 2. d4 d5 3. exd5 cxd5 4. c4 Nf6 5. Nc3 e6 6. Nf3 Be7 7. cxd5 Nxd5 8. Bd3 Nc6 9. O-O O-O 10. Re1 Nf6 11. a3 b6 12. Bc2 Bb7"],
  ["B15", "Caro-Kann Defense: Tartakower / Korchnoi Variation", "1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Nxf6+ exf6 6. c3 Bd6 7. Bd3 O-O 8. Qc2 Re8+ 9. Ne2 h5 10. Be3 Nd7 11. O-O-O Nf8"],
  ["B01", "Scandinavian Defense: Main Line 3...Qa5", "1. e4 d5 2. exd5 Qxd5 3. Nc3 Qa5 4. d4 Nf6 5. Nf3 c6 6. Bc4 Bf5 7. Bd2 e6 8. Nd5 Qd8 9. Nxf6+ Qxf6 10. Qe2 Bg4 11. O-O-O Nd7"],
  ["B01", "Scandinavian Defense: Modern Variation with 2...Nf6", "1. e4 d5 2. exd5 Nf6 3. d4 Nxd5 4. Nf3 g6 5. c4 Nb6 6. Nc3 Bg7 7. h3 O-O 8. Be3 Nc6 9. Qd2 e5 10. d5 Ne7 11. g4 f5"],
  ["B07", "Pirc Defense: Classical Variation", "1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Nf3 Bg7 5. Be2 O-O 6. O-O c6 7. a4 Nbd7 8. Re1 e5 9. Bf1 Qc7 10. h3 b6 11. Be3 Bb7"],
  ["B09", "Pirc Defense: Austrian Attack", "1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. f4 Bg7 5. Nf3 O-O 6. Bd3 Na6 7. O-O c5 8. d5 Bg4 9. h3 Bxf3 10. Qxf3 Nb4 11. Bc4 Nd7"],
  ["B04", "Alekhine's Defense: Modern Variation", "1. e4 Nf6 2. e5 Nd5 3. d4 d6 4. Nf3 dxe5 5. Nxe5 c6 6. Be2 Bf5 7. O-O Nd7 8. Nf3 e6 9. c4 N5f6 10. Nc3 Bd6 11. Nh4 Bg6"],
  ["B22", "Sicilian Defense: Alapin Variation, 2...d5", "1. e4 c5 2. c3 d5 3. exd5 Qxd5 4. d4 Nf6 5. Nf3 e6 6. Be2 Be7 7. O-O O-O 8. Be3 cxd4 9. cxd4 Nc6 10. Nc3 Qd6 11. a3 b6"],
  ["B22", "Sicilian Defense: Alapin Variation, 2...Nf6", "1. e4 c5 2. c3 Nf6 3. e5 Nd5 4. d4 cxd4 5. Nf3 Nc6 6. cxd4 d6 7. Bc4 Nb6 8. Bb5 dxe5 9. Nxe5 Bd7 10. Nxd7 Qxd7 11. O-O e6"],
  ["B31", "Sicilian Defense: Rossolimo Attack, 3...g6", "1. e4 c5 2. Nf3 Nc6 3. Bb5 g6 4. O-O Bg7 5. Re1 e5 6. b4 cxb4 7. a3 b3 8. c3 Nge7 9. d4 exd4 10. cxd4 O-O 11. Bb2 d5"],
  ["B30", "Sicilian Defense: Rossolimo Attack, 3...d6", "1. e4 c5 2. Nf3 Nc6 3. Bb5 d6 4. Bxc6+ bxc6 5. O-O e5 6. c3 Nf6 7. d4 Nxe4 8. Re1 f5 9. dxe5 d5 10. c4 Be7 11. Qa4 Bd7"],
  ["B51", "Sicilian Defense: Moscow Variation", "1. e4 c5 2. Nf3 d6 3. Bb5+ Bd7 4. Bxd7+ Qxd7 5. c4 Nf6 6. Nc3 g6 7. d4 cxd4 8. Nxd4 Bg7 9. f3 O-O 10. Be3 Rc8 11. b3 Nc6 12. O-O a6"],
  ["B33", "Sicilian Defense: Sveshnikov Variation, 9.Bxf6", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e5 6. Ndb5 d6 7. Bg5 a6 8. Na3 b5 9. Bxf6 gxf6 10. Nd5 f5 11. c3 Bg7 12. exf5 Bxf5 13. Nc2 O-O 14. Nce3 Be6 15. Bd3 f5"],
  ["B33", "Sicilian Defense: Sveshnikov Variation, 9.Nd5", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e5 6. Ndb5 d6 7. Bg5 a6 8. Na3 b5 9. Nd5 Be7 10. Bxf6 Bxf6 11. c3 Bg5 12. Nc2 O-O 13. a4 Rb8 14. axb5 axb5 15. Be2 Be6"],
  ["B35", "Sicilian Defense: Accelerated Dragon, Modern 7.Bc4", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 g6 5. Nc3 Bg7 6. Be3 Nf6 7. Bc4 O-O 8. Bb3 d6 9. f3 Bd7 10. Qd2 Rc8 11. O-O-O Ne5 12. h4 h5"],
  ["B38", "Sicilian Defense: Accelerated Dragon, Maroczy Bind", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 g6 5. c4 Bg7 6. Be3 Nf6 7. Nc3 O-O 8. Be2 d6 9. O-O Bd7 10. Qd2 Nxd4 11. Bxd4 Bc6 12. f3 a5"],
  ["B42", "Sicilian Defense: Kan Variation, 5.Bd3", "1. e4 c5 2. Nf3 e6 3. d4 cxd4 4. Nxd4 a6 5. Bd3 Bc5 6. Nb3 Be7 7. O-O d6 8. c4 Nf6 9. Nc3 O-O 10. Be3 b6 11. f4 Bb7 12. Qf3 Nbd7"],
  ["B47", "Sicilian Defense: Taimanov Variation, English Attack", "1. e4 c5 2. Nf3 e6 3. d4 cxd4 4. Nxd4 Nc6 5. Nc3 a6 6. Be3 Qc7 7. Qd2 Nf6 8. f3 Bb4 9. O-O-O d5 10. a3 Be7 11. exd5 exd5 12. g4 O-O"],
  ["B66", "Sicilian Defense: Richter-Rauzer Classical", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 d6 6. Bg5 e6 7. Qd2 a6 8. O-O-O Bd7 9. f4 b5 10. Bxf6 gxf6 11. Kb1 Qb6 12. f5 O-O-O"],
  ["B78", "Sicilian Defense: Dragon Variation, Yugoslav Attack 9.Bc4", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 g6 6. Be3 Bg7 7. f3 O-O 8. Qd2 Nc6 9. Bc4 Bd7 10. O-O-O Rc8 11. Bb3 Ne5 12. h4 h5 13. Kb1 Nc4 14. Bxc4 Rxc4"],
  ["B76", "Sicilian Defense: Dragon Variation, Yugoslav 9.O-O-O", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 g6 6. Be3 Bg7 7. f3 O-O 8. Qd2 Nc6 9. O-O-O d5 10. exd5 Nxd5 11. Nxc6 bxc6 12. Bd4 e5 13. Bc5 Be6 14. Ne4 Re8"],
  ["B81", "Sicilian Defense: Scheveningen, Keres Attack", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e6 6. g4 h6 7. h4 Nc6 8. Rg1 h5 9. gxh5 Nxh5 10. Bg5 Nf6 11. Qd2 Qb6 12. Nb3 a6 13. O-O-O Bd7"],
  ["B85", "Sicilian Defense: Scheveningen, Classical Main Line", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e6 6. Be2 a6 7. O-O Be7 8. f4 O-O 9. Be3 Qc7 10. a4 Nc6 11. Kh1 Re8 12. Bf3 Rb8 13. Qd2 Bd7"],
  ["B90", "Sicilian Defense: Najdorf, English Attack 6.Be3", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Be3 e5 7. Nb3 Be6 8. f3 Be7 9. Qd2 O-O 10. O-O-O Nbd7 11. g4 b5 12. g5 b4 13. Ne2 Ne8 14. f4 a5 15. f5 a4 16. Nbd4 exd4 17. Nxd4 b3 18. Kb1 bxc2+ 19. Nxc2 Bb3"],
  ["B92", "Sicilian Defense: Najdorf, Classical 6.Be2", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Be2 e5 7. Nb3 Be7 8. O-O O-O 9. Be3 Be6 10. Qd2 Nbd7 11. a4 Rc8 12. a5 Qc7 13. Rfd1 Rfd8 14. Qe1 Qc6"],
  ["B96", "Sicilian Defense: Najdorf, Polugaevsky Variation", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5 e6 7. f4 b5 8. e5 dxe5 9. fxe5 Qc7 10. Qe2 Nfd7 11. O-O-O Bb7 12. Qg4 Qxe5 13. Bd3 h5"],
  ["B97", "Sicilian Defense: Najdorf, Poisoned Pawn Variation", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5 e6 7. f4 Qb6 8. Qd2 Qxb2 9. Rb1 Qa3 10. f5 Nc6 11. fxe6 fxe6 12. Nxc6 bxc6 13. e5 dxe5 14. Bxf6 gxf6 15. Ne4 Be7 16. Be2 h5 17. Rb3 Qxa2 18. O-O"],
  ["B99", "Sicilian Defense: Najdorf, 6.Bg5 Main Line", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5 e6 7. f4 Be7 8. Qf3 Qc7 9. O-O-O Nbd7 10. g4 b5 11. Bxf6 Nxf6 12. g5 Nd7 13. f5 Bxg5+ 14. Kb1 Ne5 15. Qh5 Qd8 16. Rg1 Bf6 17. fxe6 O-O 18. exf7+ Rxf7"],

  // ==========================================
  // ECO C — FRENCH, RUY LOPEZ, ITALIAN, SCOTCH, PETROFF
  // ==========================================
  ["C02", "French Defense: Advance Variation", "1. e4 e6 2. d4 d5 3. e5 c5 4. c3 Nc6 5. Nf3 Qb6 6. a3 Nh6 7. b4 cxd4 8. cxd4 Nf5 9. Bb2 Bd7 10. g4 Nfe7 11. Nc3 Na5 12. Na4 Qc6 13. Nc5 Nc4"],
  ["C07", "French Defense: Tarrasch Open System", "1. e4 e6 2. d4 d5 3. Nd2 c5 4. exd5 exd5 5. Ngf3 Nf6 6. Bb5+ Bd7 7. Bxd7+ Nbxd7 8. O-O Be7 9. dxc5 Nxc5 10. Re1 O-O 11. Nf1 Re8 12. Be3 Nce4 13. Bd4 Bc5"],
  ["C11", "French Defense: Classical Steinitz Variation", "1. e4 e6 2. d4 d5 3. Nc3 Nf6 4. e5 Nfd7 5. f4 c5 6. Nf3 Nc6 7. Be3 a6 8. Qd2 b5 9. a3 Bb7 10. Be2 Be7 11. O-O O-O 12. Kh1 Rc8 13. Rad1 cxd4 14. Nxd4 Na5"],
  ["C18", "French Defense: Winawer Advance Main Line", "1. e4 e6 2. d4 d5 3. Nc3 Bb4 4. e5 c5 5. a3 Bxc3+ 6. bxc3 Ne7 7. Qg4 Qc7 8. Qxg7 Rg8 9. Qxh7 cxd4 10. Ne2 Nbc6 11. f4 Bd7 12. Qd3 dxc3 13. h4 O-O-O 14. Rb1 d4 15. h5 Nf5"],
  ["C42", "Petroff Defense: Classical Main Line", "1. e4 e5 2. Nf3 Nf6 3. Nxe5 d6 4. Nf3 Nxe4 5. d4 d5 6. Bd3 Be7 7. O-O Nc6 8. c4 Nb4 9. Be2 O-O 10. Nc3 Bf5 11. a3 Nxc3 12. bxc3 Nc6 13. Re1 Re8 14. cxd5 Qxd5"],
  ["C45", "Scotch Game: Classical Mieses Variation", "1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nf6 5. Nxc6 bxc6 6. e5 Qe7 7. Qe2 Nd5 8. c4 Ba6 9. b3 g6 10. f4 Bg7 11. Qf2 Nb6 12. Ba3 d6 13. Nc3 O-O-O 14. O-O-O"],
  ["C47", "Four Knights Game: Scotch Variation", "1. e4 e5 2. Nf3 Nc6 3. Nc3 Nf6 4. d4 exd4 5. Nxd4 Bb4 6. Nxc6 bxc6 7. Bd3 d5 8. exd5 cxd5 9. O-O O-O 10. Bg5 c6 11. Qf3 Bd6 12. h3 Rb8 13. Rab1 Be6"],
  ["C51", "Evans Gambit: Accepted Main Line", "1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bxb4 5. c3 Ba5 6. d4 exd4 7. O-O dxc3 8. Qb3 Qf6 9. e5 Qg6 10. Nxc3 Nge7 11. Ba3 O-O 12. Rad1 Bb6 13. Bd3 Qh5"],
  ["C54", "Italian Game: Giuoco Pianissimo Main Line", "1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. O-O a6 7. a4 Ba7 8. Re1 O-O 9. h3 h6 10. Nbd2 Re8 11. Nf1 Be6 12. Bxe6 Rxe6 13. Be3 Bxe3 14. Nxe3 d5 15. Qc2 Qd7 16. Rad1 Rd8"],
  ["C57", "Two Knights Defense: Polerio / Fried Liver Line", "1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Na5 6. Bb5+ c6 7. dxc6 bxc6 8. Be2 h6 9. Nf3 e4 10. Ne5 Bd6 11. d4 exd3 12. Nxd3 Qc7 13. b3 O-O 14. Bb2 Ne4 15. Nd2 Bf5"],
  ["C67", "Ruy Lopez: Berlin Defense, Endgame Line", "1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Nxe4 5. d4 Nd6 6. Bxc6 dxc6 7. dxe5 Nf5 8. Qxd8+ Kxd8 9. Nc3 Ke8 10. h3 h5 11. Bf4 Be7 12. Rad1 Be6 13. b3 Rd8 14. Rxd8+ Kxd8 15. Rd1+ Kc8 16. Ne4 Bd5 17. Neg5 f6"],
  ["C68", "Ruy Lopez: Exchange Variation", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6 dxc6 5. O-O f6 6. d4 exd4 7. Nxd4 c5 8. Nb3 Qxd1 9. Rxd1 Bd7 10. Be3 b6 11. Nc3 O-O-O 12. a4 a5 13. Nd5 Ne7"],
  ["C80", "Ruy Lopez: Open Variation", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Nxe4 6. d4 b5 7. Bb3 d5 8. dxe5 Be6 9. c3 Be7 10. Nbd2 O-O 11. Bc2 f5 12. exf6 Bxf6 13. Nxe4 dxe4 14. Bxe4 Qxd1 15. Rxd1 Rad8"],
  ["C89", "Ruy Lopez: Marshall Attack", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 O-O 8. c3 d5 9. exd5 Nxd5 10. Nxe5 Nxe5 11. Rxe5 c6 12. d4 Bd6 13. Re1 Qh4 14. g3 Qh3 15. Be3 Bg4 16. Qd3 Rae8 17. Nd2 Re6 18. a4 Qh5 19. axb5 axb5"],
  ["C92", "Ruy Lopez: Zaitsev System", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 Bb7 10. d4 Re8 11. Nbd2 Bf8 12. a4 h6 13. Bc2 exd4 14. cxd4 Nb4 15. Bb1 c5 16. d5 Nd7 17. Ra3 c4"],
  ["C97", "Ruy Lopez: Chigorin Defense", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 Na5 10. Bc2 c5 11. d4 Qc7 12. Nbd2 cxd4 13. cxd4 Nc6 14. Nb3 a5 15. Be3 a4 16. Nbd2 Bd7 17. Rc1 Qb8"],
  ["C99", "Ruy Lopez: Breyer Defense", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 Nb8 10. d4 Nbd7 11. Nbd2 Bb7 12. Bc2 Re8 13. Nf1 Bf8 14. Ng3 g6 15. a4 c5 16. d5 c4 17. Bg5 h6 18. Be3 Nc5"],

  // ==========================================
  // ECO D — QUEEN'S GAMBIT, SLAV, SEMI-SLAV, GRUNFELD
  // ==========================================
  ["D15", "Slav Defense: Chebanenko Variation", "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 a6 5. e3 b5 6. b3 Bg4 7. Be2 e6 8. O-O Nbd7 9. Bb2 Bd6 10. h3 Bh5 11. Ne5 Bxe2 12. Nxe2 Rc8 13. Rc1 O-O 14. Nf4 Qe7"],
  ["D17", "Slav Defense: Main Line Czech Variation", "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 dxc4 5. a4 Bf5 6. e3 e6 7. Bxc4 Bb4 8. O-O O-O 9. Qe2 Bg6 10. Ne5 Nbd7 11. Nxg6 hxg6 12. Rd1 Qe7 13. e4 e5 14. d5 Nb6 15. Bb3 Rad8"],
  ["D27", "Queen's Gambit Accepted: Classical Line", "1. d4 d5 2. c4 dxc4 3. Nf3 Nf6 4. e3 e6 5. Bxc4 c5 6. O-O a6 7. Bb3 b5 8. a4 Bb7 9. Qe2 Nbd7 10. Rd1 Qb8 11. Nc3 Bd6 12. h3 O-O 13. axb5 axb5 14. Rxa8 Bxa8"],
  ["D35", "Queen's Gambit Declined: Exchange Variation", "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. cxd5 exd5 5. Bg5 c6 6. e3 Be7 7. Bd3 Nbd7 8. Qc2 O-O 9. Nge2 Re8 10. O-O Nf8 11. f3 g6 12. Rad1 Ne6 13. Bh4 b6 14. Kh1 Bb7 15. e4 Rc8"],
  ["D38", "Queen's Gambit Declined: Ragozin Defense", "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Nf3 Bb4 5. cxd5 exd5 6. Bg5 h6 7. Bh4 c5 8. e3 Nbd7 9. Bd3 Qa5 10. Qc2 c4 11. Bf5 O-O 12. O-O Re8 13. Nd2 Be7"],
  ["D44", "Semi-Slav Defense: Botvinnik System", "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 e6 5. Bg5 dxc4 6. e4 b5 7. e5 h6 8. Bh4 g5 9. Nxg5 hxg5 10. Bxg5 Nbd7 11. g3 Bb7 12. Bg2 Qb6 13. exf6 O-O-O 14. O-O c5 15. d5 b4"],
  ["D45", "Semi-Slav Defense: Stoltz Variation", "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 e6 5. e3 Nbd7 6. Qc2 Bd6 7. Bd3 O-O 8. O-O dxc4 9. Bxc4 b5 10. Be2 Bb7 11. Rd1 Qc7 12. e4 e5 13. h3 a6"],
  ["D47", "Semi-Slav Defense: Meran Variation", "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 e6 5. e3 Nbd7 6. Bd3 dxc4 7. Bxc4 b5 8. Bd3 a6 9. e4 c5 10. e5 cxd4 11. Nxb5 axb5 12. exf6 gxf6 13. O-O Qb6 14. Qe2 Bb7 15. Bxb5 Bd6 16. Rd1 Rg8"],
  ["D56", "Queen's Gambit Declined: Lasker Defense", "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Be7 5. e3 O-O 6. Nf3 h6 7. Bh4 Ne4 8. Bxe7 Qxe7 9. cxd5 Nxc3 10. bxc3 exd5 11. Qb3 Rd8 12. c4 dxc4 13. Bxc4 Nc6 14. Be2 b6 15. O-O Bb7"],
  ["D58", "Queen's Gambit Declined: Tartakower Variation", "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Be7 5. e3 O-O 6. Nf3 h6 7. Bh4 b6 8. cxd5 Nxd5 9. Bxe7 Qxe7 10. Nxd5 exd5 11. Rc1 Be6 12. Qa4 c5 13. Qa3 Rc8 14. Be2 Nd7 15. O-O a5 16. Rfd1 Qf8"],
  ["D85", "Grunfeld Defense: Exchange Variation, Modern 8.Rb1", "1. d4 Nf6 2. c4 g6 3. Nc3 d5 4. cxd5 Nxd5 5. e4 Nxc3 6. bxc3 Bg7 7. Nf3 c5 8. Rb1 O-O 9. Be2 cxd4 10. cxd4 Qa5+ 11. Bd2 Qxa2 12. O-O Bg4 13. Bg5 h6 14. Be3 Nc6 15. d5 Na5 16. Bc5 b6"],
  ["D87", "Grunfeld Defense: Exchange Variation, Classical 7.Bc4", "1. d4 Nf6 2. c4 g6 3. Nc3 d5 4. cxd5 Nxd5 5. e4 Nxc3 6. bxc3 Bg7 7. Bc4 c5 8. Ne2 O-O 9. O-O Nc6 10. Be3 Bg4 11. f3 Na5 12. Bd3 cxd4 13. cxd4 Be6 14. Rc1 Bxa2 15. Qa4 Be6"],
  ["D97", "Grunfeld Defense: Russian System", "1. d4 Nf6 2. c4 g6 3. Nc3 d5 4. Nf3 Bg7 5. Qb3 dxc4 6. Qxc4 O-O 7. e4 a6 8. Be2 b5 9. Qb3 Bb7 10. e5 Nd5 11. O-O Nxc3 12. bxc3 c5 13. Be3 Nd7 14. a4 cxd4 15. cxd4 Nb6"],

  // ==========================================
  // ECO E — CATALAN, NIMZO-INDIAN, KING'S INDIAN, QUEEN'S INDIAN
  // ==========================================
  ["E04", "Catalan Opening: Open Main Line", "1. d4 Nf6 2. c4 e6 3. g3 d5 4. Bg2 dxc4 5. Nf3 a6 6. O-O Nc6 7. e3 Bd7 8. Qe2 b5 9. Rd1 Be7 10. e4 O-O 11. Nc3 Re8 12. Bf4 Rc8 13. d5 exd5 14. e5 d4"],
  ["E06", "Catalan Opening: Closed Main Line", "1. d4 Nf6 2. c4 e6 3. g3 d5 4. Bg2 Be7 5. Nf3 O-O 6. O-O Nbd7 7. Qc2 c6 8. Nbd2 b6 9. e4 Bb7 10. e5 Ne8 11. cxd5 cxd5 12. Re1 Rc8 13. Qd1 Nc7 14. Nf1 b5 15. h4 b4"],
  ["E12", "Queen's Indian Defense: Petrosian System", "1. d4 Nf6 2. c4 e6 3. Nf3 b6 4. a3 Ba6 5. Qc2 Bb7 6. Nc3 c5 7. e4 cxd4 8. Nxd4 Nc6 9. Nxc6 Bxc6 10. Bf4 Nh5 11. Be3 Bc5 12. Bxc5 bxc5 13. Qd2 O-O"],
  ["E15", "Queen's Indian Defense: Classical 4.g3 Ba6", "1. d4 Nf6 2. c4 e6 3. Nf3 b6 4. g3 Ba6 5. b3 Bb4+ 6. Bd2 Be7 7. Bg2 c6 8. Bc3 d5 9. Ne5 Nfd7 10. Nxd7 Nxd7 11. Nd2 O-O 12. O-O Rc8 13. e4 c5 14. exd5 exd5"],
  ["E32", "Nimzo-Indian Defense: Classical 4.Qc2", "1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. a3 Bxc3+ 6. Qxc3 b6 7. Bg5 Bb7 8. f3 h6 9. Bh4 d5 10. e3 Nbd7 11. cxd5 Nxd5 12. Bxd8 Nxc3 13. Bh4 Nd5 14. Bf2 c5 15. e4 N5f6"],
  ["E54", "Nimzo-Indian Defense: Rubinstein Main Line", "1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. e3 O-O 5. Bd3 d5 6. Nf3 c5 7. O-O Nc6 8. a3 Bxc3 9. bxc3 dxc4 10. Bxc4 Qc7 11. Bd3 e5 12. Qc2 Re8 13. dxe5 Nxe5 14. Nxe5 Qxe5 15. f3 Bd7"],
  ["E69", "King's Indian Defense: Fianchetto Variation", "1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. g3 O-O 5. Bg2 d6 6. O-O Nbd7 7. Nc3 e5 8. e4 c6 9. h3 Qb6 10. Re1 exd4 11. Nxd4 Re8 12. Re2 Nc5 13. Be3 a5 14. Qc2 a4 15. Rd1"],
  ["E81", "King's Indian Defense: Saemisch Variation", "1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. f3 O-O 6. Be3 e5 7. d5 Nh5 8. Qd2 f5 9. O-O-O Nd7 10. Bd3 a6 11. Nge2 Ndf6 12. Kb1 Bd7 13. exf5 gxf5 14. Ng3 f4 15. Bf2"],
  ["E97", "King's Indian Defense: Bayonet Attack", "1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Be2 e5 7. O-O Nc6 8. d5 Ne7 9. b4 Nh5 10. Re1 f5 11. Ng5 Nf6 12. f3 f4 13. b5 h6 14. Ne6 Bxe6 15. dxe6 g5 16. Nd5 c6"],
  ["E99", "King's Indian Defense: Classical Mar del Plata", "1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Be2 e5 7. O-O Nc6 8. d5 Ne7 9. Ne1 Nd7 10. Be3 f5 11. f3 f4 12. Bf2 g5 13. a4 Ng6 14. a5 Rf7 15. Nb5 a6 16. Na7 Rxa7 17. Bxa7 h5"]
];

const lines = ['eco\tname\tpgn'];
let count = 0;

for (const [eco, name, pgn] of DEEP_LINES) {
  const g = new Chess();
  const sans = pgn.replace(/\d+\.(\.\.)?/g, ' ').trim().split(/\s+/);
  for (const s of sans) {
    try {
      const m = g.move(s);
      if (!m) throw new Error(`Invalid move "${s}" in "${name}" (FEN: ${g.fen()})`);
    } catch (err) {
      console.error(`Error in ${eco} ${name} at move "${s}":`, err.message);
      process.exit(1);
    }
  }
  lines.push(`${eco}\t${name}\t${pgn}`);
  count++;
}

fs.writeFileSync(outFile, lines.join('\n') + '\n');
console.log(`Successfully validated and wrote ${count} deep main lines to ${outFile}`);
